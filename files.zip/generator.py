from __future__ import annotations

import random
from typing import Any, Sequence

from .mutator import Mutation, mutate_expression


# These seeds are intentionally limited to operators observed in the live
# operator discovery. The orchestrator must still validate every candidate
# against the current live schema before simulation.
PORTABLE_SEEDS = [
    ("rank((close-open)/(high-low+0.001))", "price_intraday", "Range-normalized intraday direction."),
    ("rank(ts_delta(close,5)/ts_delay(close,5))", "price_momentum", "Short-horizon price change relative to a lagged reference."),
    ("rank(close/ts_mean(close,20))", "price_deviation", "Mean-reversion around a moving reference."),
    ("rank(ts_corr(rank(close),rank(volume),10))", "price_volume", "Cross-series co-movement."),
]


class CandidateGenerator:
    """Generates candidate expressions from the live operator/field catalog.

    Field-type safety: BRAIN field catalogs mix MATRIX, VECTOR, and EVENT
    types. Using a VECTOR field bare (e.g. `rank(some_vector_field)`) or a
    time-series operator on an EVENT field fails simulation outright
    ("Attempted to use unknown variable" / "does not support event inputs").
    This generator resolves each field to a type-safe usable expression up
    front, so every downstream consumer (seeds, mutation field-swaps) only
    ever sees already-correct field usage.
    """

    def __init__(self, operators: Sequence[dict[str, Any]], fields: Sequence[dict[str, Any]]):
        self.operator_names = [str(x.get("name") or x.get("id") or "") for x in operators]
        self.fields = self._usable_field_expressions(fields)

    @staticmethod
    def _usable_field_expressions(fields: Sequence[dict[str, Any]]) -> list[str]:
        usable: list[str] = []
        for f in fields:
            field_id = f.get("id")
            if not field_id:
                continue
            field_type = str(f.get("type") or "").upper()
            if field_type == "VECTOR":
                # A vector field must be collapsed to a scalar before use in
                # rank()/ts_* operators. vec_avg is the safe, general default;
                # callers doing deeper vector-specific research can still
                # inspect the raw type via discovery output separately.
                usable.append(f"vec_avg({field_id})")
            elif field_type == "EVENT":
                # EVENT fields (sparse, event-dated) break most ts_* operators
                # and need trade_when-style gating this generator does not yet
                # implement. Excluding them here avoids generating expressions
                # that are guaranteed to fail simulation.
                continue
            else:
                # MATRIX (and unknown/unspecified) fields are safe to use directly.
                usable.append(str(field_id))
        return usable

    def initial(self, n: int = 12) -> list[tuple[str, str, str, str]]:
        rows: list[tuple[str, str, str, str]] = []
        for expr, family, hyp in PORTABLE_SEEDS:
            rows.append((expr, family, hyp, "seed"))
        # Add field-driven simple ratios only when the live catalog makes them plausible.
        useful = [
            f for f in self.fields
            if any(
                k in f.lower()
                for k in ("operating_income", "free_cash_flow", "est_eps", "sales", "assets", "equity")
            )
        ]
        random.shuffle(useful)
        for f in useful[: max(0, n - len(rows))]:
            rows.append((f"rank({f})", "live_field", f"Test the cross-sectional information in {f}.", "field_seed"))
        return rows[:n]

    def mutations(self, parents: list[tuple[str, str]]) -> list[Mutation]:
        out: list[Mutation] = []
        sibling_expr = parents[1][0] if len(parents) > 1 else None
        for expr, pid in parents[:4]:
            out.extend(mutate_expression(expr, candidate_id=pid, sibling=sibling_expr, fields=self.fields[:40]))
        return out
