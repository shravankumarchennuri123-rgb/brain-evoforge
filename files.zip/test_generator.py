from __future__ import annotations

from wq_evo.research.generator import CandidateGenerator


def test_vector_field_is_wrapped_in_vec_avg():
    fields = [{"id": "snt7_all_languages_views", "type": "VECTOR"}]
    gen = CandidateGenerator(operators=[], fields=fields)
    assert gen.fields == ["vec_avg(snt7_all_languages_views)"]


def test_event_field_is_excluded():
    fields = [{"id": "oth384_presentation_posnum", "type": "EVENT"}]
    gen = CandidateGenerator(operators=[], fields=fields)
    assert gen.fields == []


def test_matrix_field_passes_through_bare():
    fields = [{"id": "close", "type": "MATRIX"}]
    gen = CandidateGenerator(operators=[], fields=fields)
    assert gen.fields == ["close"]


def test_unknown_type_defaults_to_bare_field():
    fields = [{"id": "operating_income", "type": ""}]
    gen = CandidateGenerator(operators=[], fields=fields)
    assert gen.fields == ["operating_income"]


def test_mixed_catalog_produces_type_safe_pool():
    fields = [
        {"id": "close", "type": "MATRIX"},
        {"id": "snt7_all_languages_views", "type": "VECTOR"},
        {"id": "oth384_presentation_posnum", "type": "EVENT"},
        {"id": "operating_income", "type": "MATRIX"},
    ]
    gen = CandidateGenerator(operators=[], fields=fields)
    assert gen.fields == ["close", "vec_avg(snt7_all_languages_views)", "operating_income"]


def test_initial_seeds_still_generate_with_type_safe_fields():
    fields = [
        {"id": "fnd6_operating_income", "type": "MATRIX"},
        {"id": "fnd6_sales_growth_vec", "type": "VECTOR"},
    ]
    gen = CandidateGenerator(operators=[], fields=fields)
    rows = gen.initial(n=10)
    field_seeds = [r for r in rows if r[3] == "field_seed"]
    # The vector field's seed expression must carry the vec_avg wrapper, not the bare id.
    for expr, *_ in field_seeds:
        if "fnd6_sales_growth_vec" in expr:
            assert "vec_avg(fnd6_sales_growth_vec)" in expr
